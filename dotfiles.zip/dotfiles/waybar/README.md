# Waybar Configuration

Configuration for [Waybar](https://github.com/Alexays/Waybar)

Currently configured for Hyprland.

Fonts required: Lexend, JetBrainsMono NFP (or any other Nerd Font Propo variant)

## Screenshot

![waybar](https://i.imgur.com/puJrg4i.png)

## Credits

Inspired by [rxyhn dotfiles](https://github.com/rxyhn/dotfiles/)
